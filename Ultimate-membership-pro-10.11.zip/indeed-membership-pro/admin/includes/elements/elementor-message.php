<div class="ihc-error-global-dashboard-message ihc-admin-dashboard-notice-mk-message">
    <div class='ihc-close-notice ihc-js-close-admin-dashboard-mk-notice' data-name='elementor'>x</div>
    <?php echo esc_html__( "Now you can restrict Elementor Widgets with Ultimate Membership Pro by granting access to specific Memberships or Logged Users only. Check this out: ", 'ihc' );?>
    <a href="https://store.wpindeed.com/addon/elementor-widget-lock/" target="_blank">Ultimate Membership Pro - Elementor Widget Lock</a>
</div>
