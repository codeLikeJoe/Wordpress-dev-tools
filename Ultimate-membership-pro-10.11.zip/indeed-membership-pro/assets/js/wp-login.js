/*
* Ultimate Membership Pro - WP Login
*/
"use strict";
jQuery(function () {
    jQuery('input#user_login').attr('placeholder', 'Username');
    jQuery('input#user_email').attr('placeholder', 'E-mail');
    jQuery('input#user_pass').attr('placeholder', 'Password');
});
