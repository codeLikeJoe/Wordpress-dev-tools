<?php
echo 'Nothing to see here.';
