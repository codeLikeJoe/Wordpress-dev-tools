<?php if ( isset( $data['users_sm'] ) ):?>
  <?php echo ihc_print_social_media_icons( 'update', $data['users_sm'] );?>
<?php endif;?>
