<div class="ihc-popup-wrapp" id="popup_box">
	<div class="ihc-the-popup">
		<div class="ihc-popup-top">
			<div class="title"><?php echo $data['title'];?></div>
			<div class="close-bttn" onclick="ihcClosePopup();"></div>
			<div class="ihc-clear"></div>
		</div>
		<div class="ihc-popup-content">
			<?php echo $data['content'];?>
		</div>
	</div>
</div>
