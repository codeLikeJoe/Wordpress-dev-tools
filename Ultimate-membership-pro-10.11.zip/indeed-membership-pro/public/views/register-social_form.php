<form method="post" action="<?php echo IHC_URL  . 'public/social_handler.php';?>" id="ihc_social_login_form">
    <input type=hidden name=ihc_current_url value='<?php echo urlencode($url);?>' />
    <input type=hidden name=sm_register value=1 />
</form>
