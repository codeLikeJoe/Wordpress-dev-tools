<div class="ihc-user-banner" id="ihc_user_banner" style = " width: <?php echo $data['width'];?>; height: <?php echo $data['height'];?>;background-image:url(<?php echo $data['banner'];?>);" ></div>
