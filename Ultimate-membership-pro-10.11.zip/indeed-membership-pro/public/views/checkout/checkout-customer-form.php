<?php if ( $data['showUserDetails'] && $data['isRegistered'] ): ?>
<!--div class="ihc-checkout-page-box-wrapper ihc-checkout-page-customer-form-wrapper">
 <div class="ihc-checkout-page-box-title"><?php esc_html_e( 'Customer Information', 'ihc' );?></div>
 <div class="ihc-checkout-page-customer-form">
   <div class="ihc-register-14">
       <form method="post" enctype="multipart/form-data">
             <div class="iump-form-line-register iump-form-text" id="ihc_reg_text_9177">
               <label class="iump-labels-register">
                 <span class="ihc-required-sign">*</span><?php esc_html_e( 'Email', 'ihc' );?>
               </label>
               <input type="text" name="user_email" value="" placeholder="" />
             </div>

             <div class="iump-form-line-register iump-form-text" id="ihc_reg_text_531">
                 <label class="iump-labels-register"><?php esc_html_e( 'First Name', 'ihc' );?></label>
                 <input type="text" name="first_name" value="" placeholder="">
             </div>

         <input type="hidden" name="ihcaction" value="update" />
         <div class="iump-submit-form">
           <div class="iump-clear"></div>
         </div>
         </form>
   </div>
 </div>
</div-->  
<?php endif;?>