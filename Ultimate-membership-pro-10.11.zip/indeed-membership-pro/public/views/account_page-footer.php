	<div class="ihc-clear"></div>
	</div>
	<div class="ihc-user-page-footer">
		<?php if (!empty($data['content'])):?>
			<p><?php echo do_shortcode(stripslashes($data['content']));?></p>
		<?php endif;?>
	</div>	
</div> <!--end of ihc-account-page-wrapp -->
