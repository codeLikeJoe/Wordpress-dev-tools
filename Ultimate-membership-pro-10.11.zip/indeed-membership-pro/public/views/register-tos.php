<div class="ihc-tos-wrap" id="<?php echo $id;?>">
    <input type="checkbox" value="1" name="tos" class="<?php echo $class;?>" />
    <a href="<?php echo $tos_link;?>" target="_blank"><?php echo $tos_msg;?></a>
</div>
