<form  method="post" class="ihc-suspend-account-wrapper">
	<input type="submit" value="<?php esc_html_e('Suspend My Account', 'ihc');?>" />
	<input type="hidden" name="ihcaction" value="suspend" />
</form>
