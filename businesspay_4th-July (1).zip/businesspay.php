<?php
/*
* Plugin Name:BusinessPay payment gateway for Woocommerce
* Plugin URI: https://mybusinesspay.com
* Description: BusinessPay gateway for woocommerce
* Version: 0.9
* Author: Asoriba
* Author URI: https://asoriba.com/
* Developer: Asoriba Inc
* Developer URI: https://payment.asoriba.net/
* Text Domain: businesspay-payment-gateway-for-woocommerce
*
* Woo: 12345:342928dfsfhsf8429842374wdf4234sfd
* WC requires at least: 2.2
* WC tested up to: 5.2.2
*
* Copyright: © 2009-2018 WooCommerce.
* License: GNU General Public License v3.0
* License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}


add_action('plugins_loaded', 'woocommerce_api_businesspay_init', 0);
// hook and function for setting image file
add_action( 'wp_ajax_myprefix_get_image', 'myprefix_get_image');


function myprefix_get_image() {

      if(isset($_GET['id']) ){
          $image = wp_get_attachment_image( filter_input( INPUT_GET, 'id', FILTER_VALIDATE_INT ), 'thumbnail', true, array( 'id' => 'myprefix-preview-image' ) );
          update_option('myprefix_image_id', filter_input( INPUT_GET, 'id', FILTER_VALIDATE_INT ));
          $data = array(
              'image'    => $image,
          );
          wp_send_json_success( $data );
      } else {
          wp_send_json_error();
      }
      wp_die();
  }


function woocommerce_api_businesspay_init(){
  if(!class_exists('WC_Payment_Gateway')) return;

  class WC_BusinessPay extends WC_Payment_Gateway{

    public function __construct(){
      $this -> id = 'businesspay';
      $this -> method_title = 'BusinessPay';
      $this -> has_fields = false;

      $this -> init_form_fields();
      $this -> init_settings();

      $this -> title = $this -> settings['title'];
      $this -> description = $this -> settings['description'];
      $this -> api_key = $this -> settings['api_key'];
      $this -> image = get_option( 'myprefix_image_url' );
      $this -> testmode = $this -> settings['testmode'];
      $this -> currency = $this -> settings['currency'];



      $this -> msg['message'] = "";
      $this -> msg['class'] = "";

      // For the Media Selector
     add_action('init', array(&$this, 'init_payment_url'));
     add_action( 'admin_enqueue_scripts', array(&$this, 'load_wp_media_files'));

     if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
       add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
     } else {
       add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
     }

      add_action('woocommerce_api_businesspay', array(&$this, 'verify_payment'));
   }


// for woocommerce settings
    function init_form_fields(){

        $this->form_fields = array(
            'enabled' => array(
                'title'       =>  __( 'Enable/Disable', 'woocommerce' ),
                'label'   => __( 'Enable BusinessPay Gateway', 'woocommerce' ),
                'type'        => 'checkbox',
                'description' => '',
                'default'     => 'no'
            ),
            'testmode' => array(
                'title'       => 'Test mode',
                'label'   => __( 'Enable Test/Sandbox Mode', 'woocommerce' ),
                'type'        => 'checkbox',
                'description' => 'This enables the Sandbox mode which allows you to test a dummy card. See the readme file for test card details',
                'default'     => 'no',
                'desc_tip'    => true,
            ),
            'title' => array(
                'title'       => 'Title',
                'type'        => 'text',
                'description' => 'This controls the title which the user sees during checkout.',
                'default'     => 'BusinessPay',
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => 'Description',
                'type'        => 'textarea',
                'description' => 'This controls the description which the user sees during checkout.',
                'default'     => 'Pay with your visa/mastercard or mobile money wallet seamlessly.',
            ),
            'api_key' => array(
                'title'       => 'API Key',
                'type'        => 'text',
                'default'	  => 'Place your publication key (API key) here!'
            ),
            'currency' => array(
              'title' => 'Currency',
              'type' => 'select',
              'default' => 'GHS',
              'options'  => array(
            					'GHS'  => __( 'Ghana Cedis (GH₵)', 'woocommerce' ),
            					'USD' => __( 'United States Dollar ($)', 'woocommerce' ),
            				),
              'description' => 'BusinessPay currently supports only GHS and USD, for other currencies, handle conversion with a woocommerce conversion plugin'
            )
        );
    }


    public function load_wp_media_files() {

          // Enqueue WordPress media scripts
          wp_enqueue_media();
          // Enqueue custom script that will interact with wp.media
          wp_enqueue_script( 'myprefix_script', plugins_url( '/js/myscript.js' , __FILE__ ), array('jquery'), '0.6' );
      }




       public function admin_options(){
        $image_id = get_option( 'myprefix_image_id' );

        if( intval( $image_id ) > 0 ) {
            // Change with the image size you want to use
            $image = wp_get_attachment_image( $image_id, 'thumbnail', true, array( 'id' => 'myprefix-preview-image' ) );
            $image_url =  wp_get_attachment_image_src($image_id, 'thumbnail', true);
          update_option('myprefix_image_url', $image_url[0]);
        } else {
            // Some default image
            $image = '<img id="myprefix-preview-image" width="50px" height="50px" src="https://asoribawebsite.com/wp-content/uploads/2017/10/app-logo.png" />';
            $image_url = "https://asoribawebsite.com/wp-content/uploads/2017/10/app-logo.png";
            update_option('myprefix_image_url', $image_url);
        }

        echo '<h3>'.__('BusinessPay Payment Gateway', 'asoriba').'</h3>';
        echo '<p>'.__('BusinessPay is an innovative way of accepting payments for your services').'</p>';
        echo '<table class="form-table">';
        // Generate the HTML For the settings form.
        $this -> generate_settings_html();
        //HTML for the image selector
        ?><tr>

        <td align="left">
        <Label> <strong>Payment page image</strong> </Label>
        </td>
        <td align="right">
        <?php echo $image; ?>
        </td>
        <td align="left">
        <input type="hidden" name="myprefix_image_id" id="myprefix_image_id" value="<?php echo esc_attr( $image_id ); ?>" class="regular-text" />
        <input type='button' class="button-primary" value="<?php esc_attr_e( 'Select and save image', 'mytextdomain' ); ?>" id="myprefix_media_manager"/>
        </td>

        </tr>
        <?php

        echo '</table>';

    }

    /**
     *  There are no payment fields for BusinessPay, but we want to show the description if set.
     **/
    function payment_fields(){
        if($this -> description) echo wpautop(wptexturize($this -> description));
    }
    /**
     * Process the payment and return the result
     **/
    function process_payment($order_id){
        global $woocommerce;



			// we need it to get any order details
			$order = wc_get_order( $order_id );
            $order_data = $order->get_data();






			$post_url = home_url( '/' ) . '?wc-api=businesspay';
			$callback = home_url( '/' ) . '?wc-api=businesspay';

			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
                $callback = home_url( '/' ) . 'wc-api/businesspay';
				$post_url = home_url( '/' ) . 'wc-api/businesspay';
            }


			/*
			  * Array with parameters for API interaction
			 */

            if( $this -> testmode == 'yes'){
                $payment_url = 'https://sandbox.mybusinesspay.com/payment/v1.0/initialize';
                $pub_key = $this -> api_key;
            } else {
                $payment_url = 'https://app.mybusinesspay.com/payment/v1.0/initialize';
                $pub_key = $this -> api_key;
            }



			$args = array(
                'pub_key' => $pub_key  ,
				'amount' => $order->get_total(),
				'metadata' => array(
					'order_id' => $order_data['id'],
					'product_name' => 'Payment By ' . $order_data['billing']['first_name'] . ' ' . $order_data['billing']['last_name'] ,
					'product_description' => 'Payment By ' . $order_data['billing']['first_name'] . ' ' . $order_data['billing']['last_name']
				),
				'callback' => $callback ,
				'post_url' => $post_url ,
				'order_image_url' => $this -> image ,
				'sharable' => false,
				'first_name' => $order_data['billing']['first_name'],
				'last_name' => $order_data['billing']['last_name'],
				'email' => $order_data['billing']['email'],
				'phone_number' => $order_data['billing']['phone'],
                'currency' => $this -> currency
			);



			  $response = wp_remote_post($payment_url, array(
				'method' => 'POST',
				'headers' => array('Content-Type' => 'application/json',
									'Accept' => 'application/json',
									'x-widget' => 'true'),
					'sslverify' => false,
					'body' => json_encode($args)
			 		)
			  );

			 if( !is_wp_error( $response ) ) {

				 $body = json_decode( $response['body'], true );



				 if ( $body['status'] == 'success' ) {
                    // Redirect to the payment provider
					return array(
						'result' => 'success',
						'redirect' => $body['url']
					);

				 } else {
					wc_add_notice(  'Please try again. error is ' . $body['error'] , 'error' );
					return;
				}

			} else {
				wc_add_notice(  'Connection error.', 'error' );
				return;
			}
    }

    function verify_payment(){
        global $woocommerce;
        $checkout_url = $woocommerce->cart->get_checkout_url();
        $store_url = get_permalink( woocommerce_get_page_id( 'shop' ) );

      if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $data = $_GET;
      }
      if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
      }

        if( !is_wp_error( $_GET ) || !is_wp_error( $_GET ) ) {
            $order = wc_get_order( $data['metadata']['order_id'] );

            $transaction_id = $data['transaction_uuid'];

            if ( $data['status_code'] == '100') {
                // complete payment and redirect to thank you page


                $order->payment_complete();
                $order->reduce_order_stock();

                $order->update_status('completed', 'ID: ' . $transaction_id ." " );
                // some notes to customer (replace true with false to make it private)
                $order->add_order_note( 'Transaction successful. BusinessPay transaction ID is ' . $transaction_id, true );

                        // Empty cart
                $woocommerce->cart->empty_cart();

                wp_redirect( $this->get_return_url( $order ) );
                exit;


            } elseif($data['status_code'] == '0000'){
              echo "I'm here";
                //redirect to storefront
                $order->update_status('processing', 'ID: ' . $transaction_id ." " );
                $order->add_order_note( 'Transaction in progress. BusinessPay transaction ID is ' . $transaction_id, true );

                $woocommerce->cart->empty_cart();
                wp_redirect( $this->get_return_url( $order ) );
                wc_add_notice(  'Transaction in progress.', 'notice' );
                exit;
                return;

            }elseif($_GET['status_code'] == '632'){
                //redirect to storefront
                $order->update_status('canceled', 'ID: ' . $transaction_id ." " );
                $order->add_order_note( 'Transaction was canceled. BusinessPay transaction ID is ' . $transaction_id, true );
                $woocommerce->cart->empty_cart();
                wp_redirect($store_url);
                wc_add_notice(  'You have canceled your order. Your cart has been emptied', 'notice' );
                exit;
                return;

            } else {
                // generate error string
                $str = $data['error_fields'];
                $cleaned = str_replace('_', ' ', $str);
                $separated = explode(", ",$cleaned);

                $error = "There was an issue with your payment attempt. Kindly try to make the payment again: ";
                foreach($separated as $value){
                    if (!empty($value)){

                    $error = $error . $value . " ";
                    }
                }


               $order->update_status('failed', 'ID: ' . $transaction_id ." " );
               wp_redirect($checkout_url);
               wc_add_notice(  'Please try again. ' . $error , 'error' );
               return;
           }

       } else {
        wp_redirect($checkout_url);
           wc_add_notice(  'Connection error.', 'error' );
           return;
       }

    }


}

   /**
     * Add the Gateway to WooCommerce
     **/
    function woocommerce_add_businesspay_gateway($methods) {
        $methods[] = 'WC_BusinessPay';
        return $methods;
    }


    add_filter('woocommerce_payment_gateways', 'woocommerce_add_businesspay_gateway' );
}
